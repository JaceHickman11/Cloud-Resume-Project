import json
import boto3

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))

    # Handle CORS preflight
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'message': 'CORS preflight response'})
        }

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('VisitorTable')

    try:
        response = table.get_item(Key={'visitor_id': 0})
        item = response.get('Item')

        if item:
            new_value = int(item['visitor_count']) + 1
            table.update_item(
                Key={'visitor_id': 0},
                UpdateExpression='SET visitor_count = :val',
                ExpressionAttributeValues={':val': new_value}
            )
        else:
            new_value = 1
            table.put_item(
                Item={
                    'visitor_id': 0,
                    'visitor_count': new_value
                }
            )
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'Updated visitor_count': new_value})
        }

    except Exception as e:
        print("Error details:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'Error': str(e)})
        }
